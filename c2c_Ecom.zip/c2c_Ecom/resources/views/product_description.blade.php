@include('layout');
<style>
    .small-img-group{
        display: flex;
        justify-content: space-between;
    }
    .small-img-col{
        flex-basis:24%;
        cursor:pointer;
    }
</style>
<section class=" container product_description my-5 pt-5">
    <div class="row mt-5">
        <div class= "clo-lg-5 col-md-12 col-12">
            <img class="img-fluid w-100 pb-1" src="{{asset('assets/images/product-3.jpg')}}" alt="" />
            <div class="small-img-group">
                <div class="small-img-col">
                <img src="{{asset('assets/images/product-4.jpg')}}" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="{{asset('assets/images/product-4.jpg')}}" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="{{asset('assets/images/product-4.jpg')}}" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="{{asset('assets/images/product-4.jpg')}}" width="100%" class="small-img" alt="" />
                </div>


            </div>
        </div>
        <div></div>
    </div>
</section>