<html>

<head>
</head>

<body>
    <div class="Signuppage" id="signuppage">
        <h2 id="heading">login form</h2>
        <form id="form" method="post" action="{{url('successful')}}">
            @csrf

            <input type="integer" id="number" name="mnumber"><br>

            <input type="password" id="password" name="password"><br>

            <input type="submit" id="submit" value="submit">
        </form>
    </div>
</body>

</html>