<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="{{asset('assets/css/olx1.css')}}" rel="stylesheet" media="all">
    <title> olx</title>
     
</head>

<body>


    <!-- =============================== * navbar * ============================================ -->

    <div class="hedder">
        <div class="navbar">




           <!--- <img src="images/olx_logo.png">-->
           <h1>logo here</h1>

            <div class="search_box">
                <input type="text" class="searchclass" id="searchid" placeholder="Find Cars, mobile phone and More....">
                <p> <i class="fa-solid fa-magnifying-glass"></i> </p>
            </div>


            <div class="selling_page">
                <button> <i class="fa-solid fa-plus"></i>
                    <p>SELL</p>
                </button>
            </div>
            <a href="signup" class="signup">signup</a>
            <a href="https://www.w3schools.com" class="login">Login</a>

        </div>
    </div>
    <div class="categories">
        <label for="cars">All Categories</label>

<select name="cars" id="cars">
@foreach($user as $sn)
 {
    <option value="{{ $sn->category_name }}">{{ $sn->category_name }}</option>
 }
 @endforeach
</select>

    <a id="car" href="https://www.w3schools.com">Cars</a>
    <a id="motorcycle" href="https://www.w3schools.com">Motorcycles</a>
    <a id="mobile" href="https://www.w3schools.com">Mobile Phones</a>
    <a id="house" href="https://www.w3schools.com">For Sale:House & Apartments</a>
    <a id ="scooters" href="https://www.w3schools.com">Scooters</a>
    <a id="commercials" href="https://www.w3schools.com">Commercial & Other Vehicles</a>
    <a id= "rent" href="https://www.w3schools.com">For Rent:House & Apartments</a>

    
</div>
<!--<div class="section1" id="loginform">
<form method="post" action="">
   Name:<input type="text" name="name" id="name">
   Password:<input type="password" name="password"> 
</form>
</div>-->





    <!-- =============================== * ad 1 * ============================================ -->



    <div class="ad_img">
    <img src="{{asset('assets/images//ad1.jpg')}}" alt="ad1" />
        
        <i class="fa-regular fa-rectangle-xmark" id="ad_icon"></i>
    </div>




    <!-- =============================== * product * ============================================ -->


    <div class="product">
        <div class="First_row">
            <div class="box">
                <a href="produc_olx.html">
                <img src="{{asset('assets/images/product-1.jpg')}}" alt="" />
                    <h2>₹3,500</h2>
                    <p>Mi TV Stick</p>
                    <div class="addres_data">
                        <p>Bandra East, Mumbai</p>
                        <p>Today</p>
                    </div>
                </a>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-2.jpg')}}" alt="" />
                <h2> ₹4800 </h2>
                <p> xbox one s</p>
                <div class="addres_data">
                    <p>CHEMBUR, MUMBAI</p>
                    <p> JUL 27</p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-3.jpg')}}" alt="" />
                <h2> ₹7000</h2>
                <p> Refrigerator</p>
                <div class="addres_data">
                    <p>DHARAVI, MUMBAI</p>
                    <p> Today </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-4.jpg')}}" alt="" />
                <h2> ₹8,00,000 </h2>
                <p> Mitsubishi Pajero (2012) </p>
                <div class="addres_data">
                    <p>VERSOVA, MUMBAI</p>
                    <p> Today </p>
                </div>
            </div>
        </div>



        <div class="First_row">
            <div class="box">
            <img src="{{asset('assets/images/product-5.jpg')}}" alt="" />
                <h2> ₹800 </h2>
                <p> Black Jeans for man</p>
                <div class="addres_data">
                    <p>BORIVALI WEST, MUMBAI</p>
                    <p> DEC 24 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-6.jpg')}}" alt="" />
                <h2> ₹3,000 </h2>
                <p> Pricise corrom board</p>
                <div class="addres_data">
                    <p>IC COLONY, MUMBAI</p>
                    <p> JAN 29 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-7.jpg')}}" alt="" />
                <h2> ₹3,800 </h2>
                <p> CrossBeat Torq Buds</p>
                <div class="addres_data">
                    <p>DHARAVI, MUMBAI</p>
                    <p> Today </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-8.jpg')}}" alt="" />
                <h2> ₹39,000 </h2>
                <p> Nikon D7000 DSLR camera </p>
                <div class="addres_data">
                    <p>ANDHERI WEST, MUMBAI</p>
                    <p> FEB 02 </p>
                </div>
            </div>
        </div>




        <div class="First_row">
            <div class="box">
            <img src="{{asset('assets/images/product-9.jpg')}}" alt="" />
                <h2> ₹400 </h2>
                <p> Black jacket</p>
                <div class="addres_data">
                    <p>KANDIVALI WEST, MUMBAI</p>
                    <p> FEB 11 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-10.jpg')}}" alt="" />
                <h2> ₹3,400 </h2>
                <p> LG Washing machine </p>
                <div class="addres_data">
                    <p>SANTACRUZ EAST, MUMBAI</p>
                    <p> Today </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-11.jpg')}}" alt="" />
                <h2> ₹700 </h2>
                <p> Running Shoe (athletes) </p>
                <div class="addres_data">
                    <p>BANDRA EAST, MUMBAI</p>
                    <p> FEB 25 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-12.jpg')}}" alt="" />
                <h2> ₹35,000 </h2>
                <p> Antique premium teak wood Sofa set </p>
                <div class="addres_data">
                    <p>Bandra East, Mumbai</p>
                    <p> Today </p>
                </div>
            </div>
        </div>



        <div class="First_row">
            <div class="box">
            <img src="{{asset('assets/images/product-13.jpg')}}" alt="" />
                <h2> ₹3,35,000 </h2>
                <p> Hyundai I20 (2010)</p>
                <div class="addres_data">
                    <p>KHAR EAST, MUMBAI</p>
                    <p> JAN 14 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-14.jpg')}}" alt="" />
                <h2> ₹6,000 </h2>
                <p> dining table</p>
                <div class="addres_data">
                    <p>DADAR WEST, MUMBAI</p>
                    <p> JUN 10</p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-15.jpg')}}" alt="" />
                <h2> ₹1,200 </h2>
                <p> Mens fastrack watch </p>
                <div class="addres_data">
                    <p>KURLA EAST, MUMBAI</p>
                    <p> JAN 7 </p>
                </div>
            </div>
            <div class="box">
            <img src="{{asset('assets/images/product-16.jpg')}}" alt="" />
                <h2> ₹2,100 </h2>
                <p> Pure Metal Dumbbells</p>
                <div class="addres_data">
                    <p>Bandra East, Mumbai</p>
                    <p> Today </p>
                </div>
            </div>
        </div>

    </div>





    <!-- =============================== * LOde more * ============================================ -->



    <div class="LOde_more">
        <button id="Lode_more_id"> Lode More </button>



        <div class="lode-More_products" id="lode_more_products_id">
            <div class="First_row">
                <div class="box">
                    <a href="#"></a>
                    <img src="images/product-1.jpg">
                    <h2>₹3,500</h2>
                    <p>Mi TV Stick</p>
                    <div class="addres_data">
                        <p>Bandra East, Mumbai</p>
                        <p>Today</p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-2.jpg">
                    <h2> ₹4800 </h2>
                    <p> xbox one s</p>
                    <div class="addres_data">
                        <p>CHEMBUR, MUMBAI</p>
                        <p> JUL 27</p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-3.jpg">
                    <h2> ₹7000</h2>
                    <p> Refrigerator</p>
                    <div class="addres_data">
                        <p>DHARAVI, MUMBAI</p>
                        <p> Today </p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-4.jpg">
                    <h2> ₹8,00,000 </h2>
                    <p> Mitsubishi Pajero (2012) </p>
                    <div class="addres_data">
                        <p>VERSOVA, MUMBAI</p>
                        <p> Today </p>
                    </div>
                </div>
            </div>



            <div class="First_row">
                <div class="box">
                    <img src="images/product-5.jpg">
                    <h2> ₹800 </h2>
                    <p> Black Jeans for man</p>
                    <div class="addres_data">
                        <p>BORIVALI WEST, MUMBAI</p>
                        <p> DEC 24 </p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-6.jpg">
                    <h2> ₹3,000 </h2>
                    <p> Pricise corrom board</p>
                    <div class="addres_data">
                        <p>IC COLONY, MUMBAI</p>
                        <p> JAN 29 </p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-7.jpg">
                    <h2> ₹3,800 </h2>
                    <p> CrossBeat Torq Buds</p>
                    <div class="addres_data">
                        <p>DHARAVI, MUMBAI</p>
                        <p> Today </p>
                    </div>
                </div>
                <div class="box">
                    <img src="images/product-8.jpg">
                    <h2> ₹39,000 </h2>
                    <p> Nikon D7000 DSLR camera </p>
                    <div class="addres_data">
                        <p>ANDHERI WEST, MUMBAI</p>
                        <p> FEB 02 </p>
                    </div>
                </div>
            </div>




        </div>



    </div>



    <!-- =============================== * ad 2 * ============================================ -->


    <div class="ads_img2">
        <img src="images/ad2.jpg">
        <i class="fa-regular fa-rectangle-xmark" id="adicon2"></i>
    </div>




    <!-- =============================== * downlode * ============================================ -->


    <div class="downlode_app">
        <div class="downlode">
            <img src="images/footar.jpg" class="imges">

            <div class="text">
                <h1> TRY THE OLX APP</h1>
                <p>Buy, sell and find just about anything using <br>
                    the app on your mobile.</p>
            </div>
            <div class="downlode_store">
                <p> GET YOUR APP TODAY </p>
                <img src="images/play store.png" alt="">
            </div>
        </div>
    </div>




    <!-- =============================== * footer * ============================================ -->



    <div class="Main_footer">
        <div class="footer">
            <div class="footer_box">
                <h2>POPULAR LOCATIONS</h2>
                <p> Kolkata</p>
                <p>Mumbai</p>
                <p>Chennai</p>
                <p>pune</p>
            </div>
            <div class="footer_box">
                <h2>TRENDING LOCATIONS</h2>
                <p> Bhubaneshwar</p>
                <p>Hyderabad</p>
                <p>Chandigarh</p>
                <p>Nashik</p>
            </div>
            <div class="footer_box">
                <h2>ABOUT US</h2>
                <p> About OLX Group</p>
                <p>Careers</p>
                <p>Contact Us</p>
                <p>OLXPeople</p>
            </div>
            <div class="footer_box">
                <h2>OLX</h2>
                <p> Help</p>
                <p>Legal & Privacy information</p>
                <p>Blog</p>
            </div>
        </div>
    </div>

    <script>

        //  =============================== * navbar * ============================================

        let contry = document.getElementById('contry');
        let moving = document.getElementById('moving');
        let text = document.getElementById('text');
        let list = document.getElementById('list');


        contry.addEventListener('click', () => {
            list.classList.toggle('hidden');
            moving.classList.toggle('roted')
        });
        function myfunction(omkar) {
            text.innerHTML = omkar;
        }


        let eng_tag = document.getElementById('eng_tag');
        let hin_eng = document.querySelector('.hin_eng');
        let language = document.querySelector('.language');


        language.addEventListener('click', () => {
            hin_eng.classList.toggle('display_div');
        });
        function languageolx(anyone) {
            eng_tag.innerHTML = anyone;
        }

        let girl_img_id = document.getElementById('girl_img_id');
        let gropdwonid = document.getElementById('gropdwonid');

        girl_img_id.addEventListener('click', () => {
            gropdwonid.classList.toggle('block_div')
        });




        //  =============================== * ad 1 * ============================================


        let ad_img = document.querySelector('.ad_img');
        let ad_icon = document.getElementById('ad_icon');


        ad_icon.addEventListener('click', () => {
            ad_img.style = `display: none`;
        });




        //  =============================== * lode more * ============================================


        let Lode_more_id = document.getElementById('Lode_more_id');
        let lode_more_products_id = document.getElementById('lode_more_products_id');


        Lode_more_id.addEventListener('click', () => {
            lode_more_products_id.style = 'display:block';
            Lode_more_id.style = 'display:none'
        });






        //  =============================== * ad 2 * ============================================



        let adicon2 = document.getElementById('adicon2');
        let ads_img2 = document.querySelector('.ads_img2');

        adicon2.addEventListener('click', () => {
            ads_img2.style = 'display: none';
        });



    </script>

</body>

</html>