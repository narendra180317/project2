<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link href="{{asset('assets/css/olx1.css')}}" rel="stylesheet" media="all">
    <title> olx</title>

</head>

<body>


    <!-- =============================== * navbar * ============================================ -->

    <div class="hedder">
        <div class="navbar">




            <!--- <img src="images/olx_logo.png">-->
            <h1>logo here</h1>

            <div class="search_box">
                <input type="text" class="searchclass" id="searchid" placeholder="Find Cars, mobile phone and More....">
                <p> <i class="fa-solid fa-magnifying-glass"></i> </p>
            </div>


            <div class="selling_page">
                <button> <i class="fa-solid fa-plus"></i>
                    <p>SELL</p>
                </button>
            </div>
            <button class="signup" type="button">signup</button>
            <button class="login" type="button">login</button>




            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>


        </div>
    </div>