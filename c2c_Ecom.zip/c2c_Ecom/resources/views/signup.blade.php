<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="{{asset('assets/css/olx1.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('assets/css/signup.css')}}" rel="stylesheet" media="all">
    <title> olx</title>

</head>

<body>


    <!-- =============================== * navbar * ============================================ -->

    <div class="hedder">
        <div class="navbar">




            <!--- <img src="images/olx_logo.png">-->
            <h1>logo here</h1>

            <div class="search_box">
                <input type="text" class="searchclass" id="searchid" placeholder="Find Cars, mobile phone and More....">
                <p> <i class="fa-solid fa-magnifying-glass"></i> </p>
            </div>


            <div class="selling_page">
                <button> <i class="fa-solid fa-plus"></i>
                    <p>SELL</p>
                </button>
            </div>
            <button class="signup" type="button">signup</button>
            <button class="login" type="button">login</button>


        </div>
    </div>
    <div class="Signuppage" id="signuppage">
        <h2 id="heading">sign up</h2>
        <form id="form" method="post" action="home">
            @csrf
            <input type="text" id="fname" name="name" placeholder="Enter your fullname" value="{{old('name')}}"><br>
            <span class="text-danger">
                @error ('name')
                {{$message}}
                @enderror

            </span>

            <input type="integer" id="number" name="mnumber" placeholder="Phone Number" value="{{old('mnumber')}}"><br>
            <span class="text-danger">
            @error ('mnumber')
                {{$message}}
                @enderror
            </span>
            <input type="password" id="password" name="password" placeholder="password" value="{{old('password')}}"><br>
            <span class="text-danger">
            @error ('password')
                {{$message}}
                @enderror
            </span>
            <input type="submit" id="submit" value="signup">
        </form>
    </div>