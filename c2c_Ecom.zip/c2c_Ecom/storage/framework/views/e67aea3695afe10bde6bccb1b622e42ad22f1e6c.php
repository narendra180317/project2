<html>

<head>
</head>

<body>
    <div class="Signuppage" id="signuppage">
        <h2 id="heading">login form</h2>
        <form id="form" method="post" action="<?php echo e(url('successful')); ?>">
            <?php echo csrf_field(); ?>

            <input type="integer" id="number" name="mnumber"><br>

            <input type="password" id="password" name="password"><br>

            <input type="submit" id="submit" value="submit">
        </form>
    </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\c2c_Ecom\resources\views/login.blade.php ENDPATH**/ ?>