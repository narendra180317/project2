<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<style>
    .small-img-group{
        display: flex;
        justify-content: space-between;
    }
    .small-img-col{
        flex-basis:24%;
        cursor:pointer;
    }
</style>
<section class=" container product_description my-5 pt-5">
    <div class="row mt-5">
        <div class= "clo-lg-5 col-md-12 col-12">
            <img class="img-fluid w-100 pb-1" src="<?php echo e(asset('assets/images/product-3.jpg')); ?>" alt="" />
            <div class="small-img-group">
                <div class="small-img-col">
                <img src="<?php echo e(asset('assets/images/product-4.jpg')); ?>" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="<?php echo e(asset('assets/images/product-4.jpg')); ?>" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="<?php echo e(asset('assets/images/product-4.jpg')); ?>" width="100%" class="small-img" alt="" />
                </div>
                <div class="small-img-col">
                <img src="<?php echo e(asset('assets/images/product-4.jpg')); ?>" width="100%" class="small-img" alt="" />
                </div>


            </div>
        </div>
        <div></div>
    </div>
</section><?php /**PATH C:\xampp\htdocs\c2c_Ecom\resources\views/product_description.blade.php ENDPATH**/ ?>