<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="<?php echo e(asset('assets/css/olx1.css')); ?>" rel="stylesheet" media="all">
    <link href="<?php echo e(asset('assets/css/signup.css')); ?>" rel="stylesheet" media="all">
    <title> olx</title>

</head>

<body>


    <!-- =============================== * navbar * ============================================ -->

    <div class="hedder">
        <div class="navbar">




            <!--- <img src="images/olx_logo.png">-->
            <h1>logo here</h1>

            <div class="search_box">
                <input type="text" class="searchclass" id="searchid" placeholder="Find Cars, mobile phone and More....">
                <p> <i class="fa-solid fa-magnifying-glass"></i> </p>
            </div>


            <div class="selling_page">
                <button> <i class="fa-solid fa-plus"></i>
                    <p>SELL</p>
                </button>
            </div>
            <button class="signup" type="button">signup</button>
            <button class="login" type="button">login</button>


        </div>
    </div>
    <div class="Signuppage" id="signuppage">
        <h2 id="heading">sign up</h2>
        <form id="form" method="post" action="home">
            <?php echo csrf_field(); ?>
            <input type="text" id="fname" name="name" placeholder="Enter your fullname" value="<?php echo e(old('name')); ?>"><br>
            <span class="text-danger">
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </span>

            <input type="integer" id="number" name="mnumber" placeholder="Phone Number" value="<?php echo e(old('mnumber')); ?>"><br>
            <span class="text-danger">
            <?php $__errorArgs = ['mnumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            <input type="password" id="password" name="password" placeholder="password" value="<?php echo e(old('password')); ?>"><br>
            <span class="text-danger">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <?php echo e($message); ?>

                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </span>
            <input type="submit" id="submit" value="signup">
        </form>
    </div><?php /**PATH C:\xampp\htdocs\c2c_Ecom\resources\views/signup.blade.php ENDPATH**/ ?>