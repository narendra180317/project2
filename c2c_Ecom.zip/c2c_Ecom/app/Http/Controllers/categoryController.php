<?php

namespace App\Http\Controllers;
use App\Models\category;

use Illuminate\Http\Request;
use Illuminate\support\Facades\DB;

class categoryController extends Controller
{
    public function index()
    {
       $user=category::all();
       $data=compact('user');
       return view('home')->with($data);

    }
}
