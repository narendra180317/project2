<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class advertisementController extends Controller
{
    //
}
