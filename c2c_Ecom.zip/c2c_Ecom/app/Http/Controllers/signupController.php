<?php

namespace App\Http\Controllers;
use App\Models\signup;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;

class signupController extends Controller
{
    public function signup(){
        return view('signup');
    }
    public function store(Request $request){
        $request->validate([
            'name'=> 'required',
            'mnumber'=>'required|integer',
            'password'=>'required'

        ]);
        $put=new signup;
        $put->name=$request['name'];
        $put->mobile_number=$request['mnumber'];
        $put->password=Crypt::encrypt($request->input('password'));
        $put->save();
        echo "insert successful";
        //print_r($request->all());
        


    }
    public function auth(request $request){
        $result=signup::where(['mobile_number'=>$request->mnumber])->get();
        if(isset($result[0])){
            $db_pwd=Crypt::decrypt($result[0]->password);
            if($db_pwd==$request->password){
                $request->session()->put('user_login',true);
                $request->session()->put('user_name',$result[0]->name);
                return redirect('home');
            }else{
                echo "please enter valid password";
                return redirect('login');
            }

        }else{
            echo "please enter valid details";
            return redirect('login');

        }
    
    }
    public function login(){
        return view('login');
    }
}
